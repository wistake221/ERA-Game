import 'dart:math' show max;

class EraError implements Exception {
  final String message;
  EraError(this.message);
  @override
  String toString() => message;
}

enum TokType { number, str, ident, op, end }

class Token {
  final TokType type;
  final String text;
  final int value;
  final int pos;
  final int end;
  const Token(this.type, this.text, this.pos, this.end, [this.value = 0]);
}

final RegExp _identStartRe = RegExp(r'[\p{L}_]', unicode: true);
final RegExp _identPartRe = RegExp(r'[\p{L}\p{N}_]', unicode: true);

bool _isDigit(String c) {
  final u = c.codeUnitAt(0);
  return u >= 48 && u <= 57;
}

bool _isHex(String c) {
  final u = c.codeUnitAt(0);
  return (u >= 48 && u <= 57) || (u >= 65 && u <= 70) || (u >= 97 && u <= 102);
}

const List<String> _twoOps = [
  '==', '!=', '<=', '>=', '&&', '||', '<<', '>>',
  '+=', '-=', '*=', '/=', '%=', '|=', '&=', '^=', "'=",
];

List<Token> tokenize(String src) {
  final out = <Token>[];
  var i = 0;
  final n = src.length;
  while (i < n) {
    final c = src[i];
    if (c == ' ' || c == '\t' || c == '\u3000') {
      i++;
      continue;
    }
    if (c == '"') {
      final start = i;
      final sb = StringBuffer();
      i++;
      while (i < n && src[i] != '"') {
        if (src[i] == '\\' && i + 1 < n) {
          final d = src[i + 1];
          if (d == 'n') {
            sb.write('\n');
          } else if (d == 't') {
            sb.write('\t');
          } else {
            sb.write(d);
          }
          i += 2;
        } else {
          sb.write(src[i]);
          i++;
        }
      }
      if (i >= n) throw EraError('字串缺少結尾的引號');
      i++;
      out.add(Token(TokType.str, sb.toString(), start, i));
      continue;
    }
    if (_isDigit(c)) {
      final start = i;
      if (c == '0' && i + 1 < n && (src[i + 1] == 'x' || src[i + 1] == 'X')) {
        var j = i + 2;
        while (j < n && _isHex(src[j])) {
          j++;
        }
        final v = int.tryParse(src.substring(i + 2, j), radix: 16) ?? 0;
        out.add(Token(TokType.number, src.substring(i, j), start, j, v));
        i = j;
      } else {
        var j = i;
        while (j < n && _isDigit(src[j])) {
          j++;
        }
        final v = int.tryParse(src.substring(i, j)) ?? 0;
        out.add(Token(TokType.number, src.substring(i, j), start, j, v));
        i = j;
      }
      continue;
    }
    if (_identStartRe.hasMatch(c)) {
      var j = i + 1;
      while (j < n && _identPartRe.hasMatch(src[j])) {
        j++;
      }
      out.add(Token(TokType.ident, src.substring(i, j), i, j));
      i = j;
      continue;
    }
    if (i + 1 < n) {
      final two = src.substring(i, i + 2);
      if (_twoOps.contains(two)) {
        out.add(Token(TokType.op, two, i, i + 2));
        i += 2;
        continue;
      }
    }
    out.add(Token(TokType.op, c, i, i + 1));
    i++;
  }
  out.add(Token(TokType.end, '', n, n));
  return out;
}

bool truthy(dynamic v) {
  if (v is int) return v != 0;
  if (v is String) return v.isNotEmpty;
  return false;
}

int toInt(dynamic v) {
  if (v is int) return v;
  if (v is String) {
    final n = int.tryParse(v.trim());
    if (n != null) return n;
    throw EraError('無法把字串轉成數值：$v');
  }
  throw EraError('無法轉成數值');
}

String toStr(dynamic v) => v.toString();

int _cmp(dynamic a, dynamic b) {
  if (a is int && b is int) return a.compareTo(b);
  return toStr(a).compareTo(toStr(b));
}

dynamic evalBinary(String op, dynamic a, dynamic b) {
  switch (op) {
    case '+':
      if (a is String || b is String) return toStr(a) + toStr(b);
      return toInt(a) + toInt(b);
    case '-':
      return toInt(a) - toInt(b);
    case '*':
      if (a is String) {
        return List.filled(max(0, toInt(b)), a).join();
      }
      return toInt(a) * toInt(b);
    case '/':
      {
        final d = toInt(b);
        if (d == 0) throw EraError('除以零');
        return toInt(a) ~/ d;
      }
    case '%':
      {
        final d = toInt(b);
        if (d == 0) throw EraError('除以零');
        return toInt(a).remainder(d);
      }
    case '&':
      return toInt(a) & toInt(b);
    case '|':
      return toInt(a) | toInt(b);
    case '^':
      return toInt(a) ^ toInt(b);
    case '<<':
      return toInt(a) << toInt(b);
    case '>>':
      return toInt(a) >> toInt(b);
    case '==':
      return _cmp(a, b) == 0 ? 1 : 0;
    case '!=':
      return _cmp(a, b) != 0 ? 1 : 0;
    case '<':
      return _cmp(a, b) < 0 ? 1 : 0;
    case '>':
      return _cmp(a, b) > 0 ? 1 : 0;
    case '<=':
      return _cmp(a, b) <= 0 ? 1 : 0;
    case '>=':
      return _cmp(a, b) >= 0 ? 1 : 0;
  }
  throw EraError('不支援的運算子：$op');
}

abstract class ExprContext {
  dynamic getVar(String name, List<int> idx);
  dynamic callFunc(String name, List<dynamic> args);
}

class LValue {
  final String name;
  final List<int> idx;
  const LValue(this.name, this.idx);
}

class ExprParser {
  final List<Token> toks;
  final ExprContext ctx;
  int i = 0;

  ExprParser(this.toks, this.ctx);

  Token get cur => toks[i];
  Token peek(int k) => (i + k < toks.length) ? toks[i + k] : toks.last;
  bool get atEnd => cur.type == TokType.end;
  void advance() {
    if (i < toks.length - 1) i++;
  }

  bool _isOp(String s) => cur.type == TokType.op && cur.text == s;

  void _expect(String s) {
    if (!_isOp(s)) throw EraError('預期出現「$s」');
    advance();
  }

  dynamic parseExpr() => _ternary();

  List<dynamic> parseList() {
    final out = <dynamic>[];
    out.add(parseExpr());
    while (_isOp(',')) {
      advance();
      out.add(parseExpr());
    }
    return out;
  }

  LValue parseLValue() {
    if (cur.type != TokType.ident) throw EraError('預期變數名稱');
    final name = cur.text.toUpperCase();
    advance();
    final idx = <int>[];
    while (_isOp(':')) {
      advance();
      idx.add(toInt(_indexPrimary()));
    }
    return LValue(name, idx);
  }

  dynamic _ternary() {
    final c = _or();
    if (_isOp('?')) {
      advance();
      final a = _ternary();
      if (!_isOp('#')) throw EraError('三元運算子缺少「#」');
      advance();
      final b = _ternary();
      return truthy(c) ? a : b;
    }
    return c;
  }

  dynamic _or() {
    var l = _and();
    while (_isOp('||')) {
      advance();
      final r = _and();
      l = (truthy(l) || truthy(r)) ? 1 : 0;
    }
    return l;
  }

  dynamic _and() {
    var l = _bitOr();
    while (_isOp('&&')) {
      advance();
      final r = _bitOr();
      l = (truthy(l) && truthy(r)) ? 1 : 0;
    }
    return l;
  }

  dynamic _bitOr() {
    var l = _bitXor();
    while (_isOp('|')) {
      advance();
      l = evalBinary('|', l, _bitXor());
    }
    return l;
  }

  dynamic _bitXor() {
    var l = _bitAnd();
    while (_isOp('^')) {
      advance();
      l = evalBinary('^', l, _bitAnd());
    }
    return l;
  }

  dynamic _bitAnd() {
    var l = _eq();
    while (_isOp('&')) {
      advance();
      l = evalBinary('&', l, _eq());
    }
    return l;
  }

  dynamic _eq() {
    var l = _rel();
    while (_isOp('==') || _isOp('!=')) {
      final op = cur.text;
      advance();
      l = evalBinary(op, l, _rel());
    }
    return l;
  }

  dynamic _rel() {
    var l = _shift();
    while (_isOp('<') || _isOp('>') || _isOp('<=') || _isOp('>=')) {
      final op = cur.text;
      advance();
      l = evalBinary(op, l, _shift());
    }
    return l;
  }

  dynamic _shift() {
    var l = _add();
    while (_isOp('<<') || _isOp('>>')) {
      final op = cur.text;
      advance();
      l = evalBinary(op, l, _add());
    }
    return l;
  }

  dynamic _add() {
    var l = _mul();
    while (_isOp('+') || _isOp('-')) {
      final op = cur.text;
      advance();
      l = evalBinary(op, l, _mul());
    }
    return l;
  }

  dynamic _mul() {
    var l = _unary();
    while (_isOp('*') || _isOp('/') || _isOp('%')) {
      final op = cur.text;
      advance();
      l = evalBinary(op, l, _unary());
    }
    return l;
  }

  dynamic _unary() {
    if (_isOp('-')) {
      advance();
      return -toInt(_unary());
    }
    if (_isOp('+')) {
      advance();
      return toInt(_unary());
    }
    if (_isOp('!')) {
      advance();
      return truthy(_unary()) ? 0 : 1;
    }
    if (_isOp('~')) {
      advance();
      return ~toInt(_unary());
    }
    return _primary();
  }

  List<dynamic> _args() {
    if (_isOp(')')) return <dynamic>[];
    return parseList();
  }

  dynamic _primary() {
    final tk = cur;
    if (tk.type == TokType.number) {
      advance();
      return tk.value;
    }
    if (tk.type == TokType.str) {
      advance();
      return tk.text;
    }
    if (_isOp('(')) {
      advance();
      final v = parseExpr();
      _expect(')');
      return v;
    }
    if (tk.type == TokType.ident) {
      final name = tk.text.toUpperCase();
      advance();
      if (_isOp('(')) {
        advance();
        final args = _args();
        _expect(')');
        return ctx.callFunc(name, args);
      }
      final idx = <int>[];
      while (_isOp(':')) {
        advance();
        idx.add(toInt(_indexPrimary()));
      }
      return ctx.getVar(name, idx);
    }
    throw EraError('無法解析的運算式內容：「${tk.text}」');
  }

  dynamic _indexPrimary() {
    final tk = cur;
    if (tk.type == TokType.number) {
      advance();
      return tk.value;
    }
    if (_isOp('(')) {
      advance();
      final v = parseExpr();
      _expect(')');
      return v;
    }
    if (_isOp('-')) {
      advance();
      return -toInt(_indexPrimary());
    }
    if (tk.type == TokType.ident) {
      final name = tk.text.toUpperCase();
      advance();
      if (_isOp('(')) {
        advance();
        final args = _args();
        _expect(')');
        return ctx.callFunc(name, args);
      }
      return ctx.getVar(name, const <int>[]);
    }
    throw EraError('變數索引格式錯誤');
  }
}
