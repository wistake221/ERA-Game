import 'dart:async';
import 'dart:math' show Random, max, min, pow, sqrt;

import 'expr.dart';

const int kDefaultColor = 0xFFEEEEEE;

class Seg {
  final String text;
  final int color;
  const Seg(this.text, this.color);
}

class OutLine {
  final List<Seg> segs = [];
  bool rule = false;

  String get text {
    final sb = StringBuffer();
    for (final s in segs) {
      sb.write(s.text);
    }
    return sb.toString();
  }
}

class EraFunction {
  final String name;
  final List<String> params;
  final List<String> lines = [];
  final List<int> lineNo = [];
  final Map<int, int> nextBranch = {};
  final Map<int, int> endOf = {};
  final Map<int, int> startOf = {};
  final Map<int, int> loopOf = {};
  final Map<String, int> labels = {};

  EraFunction(this.name, this.params);
}

class Frame {
  final EraFunction fn;
  int pc = 0;
  final Map<String, dynamic> locals = {};
  final Map<int, List<int>> forState = {};

  Frame(this.fn);
}

enum RunState { idle, running, waitKey, waitNum, waitStr, ended }

final RegExp _cmdRe = RegExp(r'^([A-Za-z_][A-Za-z0-9_]*)');
final RegExp _printRe = RegExp(r'^PRINT(FORM|V|S)?(L|W)?$');
final RegExp _nameRe = RegExp(r'^[\p{L}\p{N}_]+', unicode: true);
final RegExp _caseIsRe =
    RegExp(r'^IS\s*(<=|>=|==|!=|<|>)\s*(.+)$', caseSensitive: false);
final RegExp _caseToRe = RegExp(r'^(.+?)\s+TO\s+(.+)$', caseSensitive: false);

class Interpreter implements ExprContext {
  final Map<String, EraFunction> funcs = {};
  final Set<String> stringVars = {};
  final Map<String, dynamic> vars = {};
  final List<Frame> stack = [];
  final List<OutLine> lines = [OutLine()];

  final Random _rng = Random();
  final Map<String, List<Token>> _tokCache = {};
  final Set<String> _warned = {};

  int color = kDefaultColor;
  RunState state = RunState.idle;
  int buttonsFrom = 0;
  void Function()? onChange;

  Completer<String>? _input;
  String? _beginTarget;
  String _currentBegin = '';
  bool _disposed = false;
  String _curFunc = '';
  int _curLine = 0;

  static const Set<String> _builtinStr = {
    'RESULTS', 'LOCALS', 'ARGS', 'NAME', 'CALLNAME', 'NICKNAME',
    'MASTERNAME', 'SAVESTR', 'STR', 'TSTR',
  };

  static const Map<String, String> _beginMap = {
    'TITLE': 'SYSTEM_TITLE',
    'FIRST': 'EVENTFIRST',
    'SHOP': 'SHOW_SHOP',
    'TRAIN': 'EVENTTRAIN',
    'AFTERTRAIN': 'EVENTEND',
    'TURNEND': 'EVENTTURNEND',
  };

  static const Map<String, String> _afterBegin = {
    'FIRST': 'SHOP',
  };

  static const Set<String> _ignored = {
    'ALIGNMENT', 'FONTBOLD', 'FONTITALIC', 'FONTREGULAR', 'FONTSTYLE',
    'SETFONT', 'RESETBGCOLOR', 'SETBGCOLOR', 'REDRAW', 'SKIPDISP', 'NOSKIP',
    'ENDNOSKIP', 'CLEARLINE', 'RANDOMIZE', 'INITRAND', 'DUMPRAND',
    'SAVEGLOBAL', 'LOADGLOBAL', 'DEBUGPRINT', 'DEBUGPRINTL', 'DEBUGCLEAR',
    'CUSTOMDRAWLINE', 'DRAWLINEFORM', 'ENDIF', 'ENDSELECT', 'DO',
  };

  // ---------------------------------------------------------------- loading

  void loadSource(String text) {
    EraFunction? cur;
    final rawLines = text.split('\n');
    for (var n = 0; n < rawLines.length; n++) {
      var raw = rawLines[n];
      if (raw.endsWith('\r')) raw = raw.substring(0, raw.length - 1);
      var line = raw.trim();
      if (n == 0 && line.startsWith('\uFEFF')) {
        line = line.substring(1).trim();
      }
      if (line.isEmpty || line.startsWith(';')) continue;
      if (line.startsWith('@')) {
        cur = _parseHeader(line.substring(1));
        funcs[cur.name] = cur;
        continue;
      }
      if (line.startsWith('#')) {
        _parseDirective(line);
        continue;
      }
      if (cur == null) continue;
      cur.lines.add(_stripComment(line));
      cur.lineNo.add(n + 1);
    }
    for (final f in funcs.values) {
      _buildJumps(f);
    }
  }

  EraFunction _parseHeader(String header) {
    final h = header.trim();
    final m = _nameRe.firstMatch(h);
    if (m == null) throw EraError('函式名稱格式錯誤：@$h');
    final name = m.group(0)!.toUpperCase();
    var rest = h.substring(m.end).trim();
    if (rest.startsWith('(') && rest.endsWith(')')) {
      rest = rest.substring(1, rest.length - 1);
    } else if (rest.startsWith(',')) {
      rest = rest.substring(1);
    }
    final params = <String>[];
    if (rest.trim().isNotEmpty) {
      for (final p in _splitTop(rest)) {
        params.add(p.split('=').first.trim());
      }
    }
    return EraFunction(name, params);
  }

  void _parseDirective(String line) {
    final up = line.toUpperCase();
    if (!up.startsWith('#DIMS')) return;
    const modifiers = {
      'DYNAMIC', 'CONST', 'GLOBAL', 'SAVEDATA', 'REF', 'CHARADATA', 'STATIC',
    };
    final words = line
        .substring(5)
        .split(RegExp(r'[\s,]+'))
        .where((w) => w.isNotEmpty);
    for (final w in words) {
      if (modifiers.contains(w.toUpperCase())) continue;
      if (_nameRe.hasMatch(w) && int.tryParse(w) == null) {
        stringVars.add(w.toUpperCase());
      }
      break;
    }
  }

  String _stripComment(String line) {
    final m = _cmdRe.firstMatch(line);
    if (m != null && m.group(1)!.toUpperCase().startsWith('PRINT')) {
      return line;
    }
    var inStr = false;
    for (var i = 0; i < line.length; i++) {
      final c = line[i];
      if (c == '"') {
        inStr = !inStr;
      } else if (c == '\\' && inStr) {
        i++;
      } else if (c == ';' && !inStr) {
        return line.substring(0, i).trimRight();
      }
    }
    return line;
  }

  String _cmdOf(String line) {
    final m = _cmdRe.firstMatch(line);
    return m == null ? '' : m.group(1)!.toUpperCase();
  }

  void _buildJumps(EraFunction f) {
    f.nextBranch.clear();
    f.endOf.clear();
    f.startOf.clear();
    f.loopOf.clear();
    f.labels.clear();

    final ifStack = <List<int>>[];
    final loopStack = <int>[];
    final selStack = <List<int>>[];

    EraError err(int i, String msg) =>
        EraError('@${f.name} 第 ${f.lineNo[i]} 行：$msg');

    for (var i = 0; i < f.lines.length; i++) {
      final line = f.lines[i];
      final cmd = _cmdOf(line);
      f.loopOf[i] = loopStack.isEmpty ? -1 : loopStack.last;
      switch (cmd) {
        case 'IF':
          ifStack.add([i]);
          break;
        case 'ELSEIF':
        case 'ELSE':
          {
            if (ifStack.isEmpty) throw err(i, '$cmd 沒有對應的 IF');
            final chain = ifStack.last;
            f.nextBranch[chain.last] = i;
            chain.add(i);
            break;
          }
        case 'ENDIF':
          {
            if (ifStack.isEmpty) throw err(i, 'ENDIF 沒有對應的 IF');
            final chain = ifStack.removeLast();
            f.nextBranch[chain.last] = i;
            for (final h in chain) {
              f.endOf[h] = i;
            }
            break;
          }
        case 'WHILE':
        case 'FOR':
        case 'DO':
          loopStack.add(i);
          break;
        case 'WEND':
        case 'NEXT':
        case 'LOOP':
          {
            if (loopStack.isEmpty) throw err(i, '$cmd 沒有對應的迴圈開頭');
            final h = loopStack.removeLast();
            f.endOf[h] = i;
            f.startOf[i] = h;
            break;
          }
        case 'SELECTCASE':
          selStack.add([i]);
          break;
        case 'CASE':
        case 'CASEELSE':
          {
            if (selStack.isEmpty) throw err(i, '$cmd 沒有對應的 SELECTCASE');
            final chain = selStack.last;
            f.nextBranch[chain.last] = i;
            chain.add(i);
            break;
          }
        case 'ENDSELECT':
          {
            if (selStack.isEmpty) {
              throw err(i, 'ENDSELECT 沒有對應的 SELECTCASE');
            }
            final chain = selStack.removeLast();
            f.nextBranch[chain.last] = i;
            for (final h in chain) {
              f.endOf[h] = i;
            }
            break;
          }
        default:
          if (line.startsWith(r'$')) {
            f.labels[line.substring(1).trim().toUpperCase()] = i;
          }
      }
    }
    if (ifStack.isNotEmpty) {
      throw err(ifStack.last.first, 'IF 缺少 ENDIF');
    }
    if (loopStack.isNotEmpty) {
      throw err(loopStack.last, '迴圈缺少結尾（WEND / NEXT / LOOP）');
    }
    if (selStack.isNotEmpty) {
      throw err(selStack.last.first, 'SELECTCASE 缺少 ENDSELECT');
    }
  }

  // -------------------------------------------------------------- utilities

  List<String> _splitTop(String s) {
    final out = <String>[];
    var depth = 0;
    var inStr = false;
    var start = 0;
    for (var i = 0; i < s.length; i++) {
      final c = s[i];
      if (inStr) {
        if (c == '\\') {
          i++;
        } else if (c == '"') {
          inStr = false;
        }
        continue;
      }
      if (c == '"') {
        inStr = true;
      } else if (c == '(') {
        depth++;
      } else if (c == ')') {
        depth--;
      } else if (c == ',' && depth == 0) {
        out.add(s.substring(start, i).trim());
        start = i + 1;
      }
    }
    out.add(s.substring(start).trim());
    return out;
  }

  int _findClose(String s, int from, String close) {
    var inStr = false;
    for (var i = from; i < s.length; i++) {
      final c = s[i];
      if (inStr) {
        if (c == '\\') {
          i++;
        } else if (c == '"') {
          inStr = false;
        }
        continue;
      }
      if (c == '"') {
        inStr = true;
        continue;
      }
      if (c == close) return i;
    }
    return -1;
  }

  List<Token> _tok(String src) {
    final cached = _tokCache[src];
    if (cached != null) return cached;
    final t = tokenize(src);
    _tokCache[src] = t;
    return t;
  }

  dynamic _eval(String src) {
    final p = ExprParser(_tok(src), this);
    final v = p.parseExpr();
    if (!p.atEnd) throw EraError('運算式後面有多餘的內容：$src');
    return v;
  }

  List<dynamic> _evalList(String src) {
    if (src.trim().isEmpty) return <dynamic>[];
    final p = ExprParser(_tok(src), this);
    final v = p.parseList();
    if (!p.atEnd) throw EraError('運算式後面有多餘的內容：$src');
    return v;
  }

  String _formatForm(String s) {
    final sb = StringBuffer();
    var i = 0;
    while (i < s.length) {
      final c = s[i];
      if (c == '\\' && i + 1 < s.length) {
        final d = s[i + 1];
        sb.write(d == 'n' ? '\n' : d);
        i += 2;
        continue;
      }
      if (c == '{' || c == '%') {
        final close = _findClose(s, i + 1, c == '{' ? '}' : '%');
        if (close > i) {
          final parts = _splitTop(s.substring(i + 1, close));
          if (parts.isNotEmpty && parts[0].isNotEmpty) {
            sb.write(toStr(_eval(parts[0])));
          }
          i = close + 1;
          continue;
        }
      }
      sb.write(c);
      i++;
    }
    return sb.toString();
  }

  // -------------------------------------------------------------- variables

  bool _isLocalName(String n) =>
      n == 'ARG' || n == 'ARGS' || n == 'LOCAL' || n == 'LOCALS';

  bool _isStringVar(String n) => stringVars.contains(n) || _builtinStr.contains(n);

  String _key(String name, List<int> idx) {
    if (idx.isEmpty || (idx.length == 1 && idx[0] == 0)) return name;
    return '$name:${idx.join(':')}';
  }

  Map<String, dynamic> _storeFor(String name) {
    if (_isLocalName(name) && stack.isNotEmpty) return stack.last.locals;
    return vars;
  }

  @override
  dynamic getVar(String name, List<int> idx) {
    final v = _storeFor(name)[_key(name, idx)];
    if (v != null) return v;
    return _isStringVar(name) ? '' : 0;
  }

  void setVar(String name, List<int> idx, dynamic value) {
    final v = _isStringVar(name) ? toStr(value) : value;
    _storeFor(name)[_key(name, idx)] = v;
  }

  void _assignText(String text, dynamic value) {
    final p = ExprParser(_tok(text), this);
    final lv = p.parseLValue();
    setVar(lv.name, lv.idx, value);
  }

  // ----------------------------------------------------------------- output

  void _write(String text) {
    if (text.isEmpty) return;
    final parts = text.split('\n');
    for (var i = 0; i < parts.length; i++) {
      if (i > 0) _newLine();
      if (parts[i].isNotEmpty) lines.last.segs.add(Seg(parts[i], color));
    }
  }

  void _newLine() {
    lines.add(OutLine());
    if (lines.length > 3000) {
      lines.removeRange(0, 1000);
      buttonsFrom = max(0, buttonsFrom - 1000);
    }
  }

  void _rule() {
    if (lines.last.segs.isNotEmpty) _newLine();
    lines.last.rule = true;
    _newLine();
  }

  void _note(String msg, int noteColor) {
    final saved = color;
    color = noteColor;
    if (lines.last.segs.isNotEmpty) _newLine();
    _write(msg);
    _newLine();
    color = saved;
  }

  void _changed() {
    if (_disposed) return;
    onChange?.call();
  }

  void reportError(String msg) {
    _note('[錯誤] $msg', 0xFFFF6B6B);
    state = RunState.ended;
    stack.clear();
    _changed();
  }

  // ------------------------------------------------------------ input / run

  bool get waitingInput =>
      state == RunState.waitNum || state == RunState.waitStr;

  void submitInput(String s) {
    final c = _input;
    if (c != null && !c.isCompleted) c.complete(s);
  }

  void advance() {
    if (state == RunState.waitKey) submitInput('');
  }

  void dispose() {
    _disposed = true;
    final c = _input;
    if (c != null && !c.isCompleted) c.complete('');
  }

  Future<String> _awaitInput(RunState s) async {
    if (_disposed) return '';
    state = s;
    final c = Completer<String>();
    _input = c;
    _changed();
    final v = await c.future;
    _input = null;
    if (_disposed) return '';
    state = RunState.running;
    if (s != RunState.waitKey) {
      if (lines.last.segs.isNotEmpty) _newLine();
      buttonsFrom = lines.length - 1;
    }
    _changed();
    return v;
  }

  Future<void> start() async {
    if (state != RunState.idle) return;
    if (funcs.containsKey('SYSTEM_TITLE')) {
      _beginTarget = 'TITLE';
    } else if (funcs.containsKey('MAIN')) {
      _beginTarget = 'MAIN';
    } else {
      reportError('找不到 @SYSTEM_TITLE 或 @MAIN，無法決定起點');
      return;
    }
    await _run();
  }

  void _enterBegin() {
    final t = _beginTarget!;
    _beginTarget = null;
    _currentBegin = t;
    final mapped = _beginMap[t];
    final name = (mapped != null && funcs.containsKey(mapped)) ? mapped : t;
    final fn = funcs[name];
    if (fn == null) throw EraError('找不到 BEGIN 的目標函式：$t');
    stack.add(Frame(fn));
  }

  void _finish(String? msg) {
    if (msg != null) _note(msg, 0xFF888888);
    stack.clear();
    _beginTarget = null;
    state = RunState.ended;
  }

  Future<void> _run() async {
    state = RunState.running;
    var steps = 0;
    try {
      while (!_disposed && state != RunState.ended) {
        if (stack.isEmpty) {
          if (_beginTarget == null) {
            final nxt = _afterBegin[_currentBegin];
            if (nxt != null && funcs.containsKey(_beginMap[nxt] ?? nxt)) {
              _beginTarget = nxt;
            } else {
              _finish('（腳本已執行完畢）');
              break;
            }
          }
          _enterBegin();
          continue;
        }
        final f = stack.last;
        if (f.pc >= f.fn.lines.length) {
          stack.removeLast();
          continue;
        }
        final ln = f.pc;
        f.pc++;
        _curFunc = f.fn.name;
        _curLine = f.fn.lineNo[ln];
        await _exec(f, f.fn.lines[ln], ln);
        steps++;
        if (steps % 500 == 0) {
          _changed();
          await Future<void>.delayed(Duration.zero);
        }
      }
    } on EraError catch (e) {
      reportError('@$_curFunc 第 $_curLine 行：${e.message}');
    } catch (e) {
      reportError('@$_curFunc 第 $_curLine 行：內部錯誤 $e');
    }
    _changed();
  }

  // ------------------------------------------------------------- statements

  Future<void> _exec(Frame f, String line, int ln) async {
    final m = _cmdRe.firstMatch(line);
    if (m == null) {
      if (line.startsWith(r'$')) return;
      if (_tryAssign(line)) return;
      _warnOnce(line);
      return;
    }
    final cmd = m.group(1)!.toUpperCase();
    final rest = line.substring(m.end);

    final pm = _printRe.firstMatch(cmd);
    if (pm != null) {
      await _doPrint(pm.group(1) ?? '', pm.group(2) ?? '', rest);
      return;
    }

    switch (cmd) {
      case 'DRAWLINE':
        _rule();
        return;
      case 'WAIT':
        await _awaitInput(RunState.waitKey);
        return;
      case 'INPUT':
        await _doInput(rest, false);
        return;
      case 'INPUTS':
        await _doInput(rest, true);
        return;
      case 'RETURN':
        _doReturn(rest);
        return;
      case 'RESTART':
        f.pc = 0;
        return;
      case 'QUIT':
        _finish('— 遊戲結束 —');
        return;
      case 'BEGIN':
        _beginTarget = rest.trim().toUpperCase();
        stack.clear();
        return;
      case 'CALL':
        _doCall(false, rest);
        return;
      case 'TRYCALL':
        _doCall(true, rest);
        return;
      case 'GOTO':
        {
          final label = rest.trim().replaceFirst(r'$', '').toUpperCase();
          final target = f.fn.labels[label];
          if (target == null) throw EraError('找不到標籤：$label');
          f.pc = target;
          return;
        }
      case 'IF':
        if (!truthy(_eval(rest))) f.pc = _skipIf(f, ln);
        return;
      case 'ELSEIF':
      case 'ELSE':
      case 'CASE':
      case 'CASEELSE':
        f.pc = f.fn.endOf[ln]! + 1;
        return;
      case 'SIF':
        if (!truthy(_eval(rest))) f.pc++;
        return;
      case 'SELECTCASE':
        _doSelect(f, ln, rest);
        return;
      case 'WHILE':
        if (!truthy(_eval(rest))) f.pc = f.fn.endOf[ln]! + 1;
        return;
      case 'WEND':
        f.pc = f.fn.startOf[ln]!;
        return;
      case 'LOOP':
        if (truthy(_eval(rest))) f.pc = f.fn.startOf[ln]! + 1;
        return;
      case 'FOR':
        _doFor(f, ln, rest);
        return;
      case 'NEXT':
        _doNext(f, ln);
        return;
      case 'BREAK':
        {
          final h = f.fn.loopOf[ln] ?? -1;
          if (h < 0) throw EraError('BREAK 不在迴圈內');
          f.pc = f.fn.endOf[h]! + 1;
          return;
        }
      case 'CONTINUE':
        {
          final h = f.fn.loopOf[ln] ?? -1;
          if (h < 0) throw EraError('CONTINUE 不在迴圈內');
          f.pc = f.fn.endOf[h]!;
          return;
        }
      case 'SETCOLOR':
        {
          final a = _evalList(rest);
          if (a.length == 1) {
            color = 0xFF000000 | (toInt(a[0]) & 0xFFFFFF);
          } else if (a.length >= 3) {
            color = 0xFF000000 |
                ((toInt(a[0]) & 0xFF) << 16) |
                ((toInt(a[1]) & 0xFF) << 8) |
                (toInt(a[2]) & 0xFF);
          }
          return;
        }
      case 'RESETCOLOR':
        color = kDefaultColor;
        return;
    }

    if (_ignored.contains(cmd)) return;
    if (_tryAssign(line)) return;
    _warnOnce(cmd);
  }

  void _warnOnce(String what) {
    if (_warned.add(what)) {
      _note('[略過不支援的指令：$what（@$_curFunc 第 $_curLine 行）]', 0xFF999999);
    }
  }

  Future<void> _doPrint(String kind, String end, String rest) async {
    String raw() {
      if (rest.startsWith(' ') || rest.startsWith('\t')) {
        return rest.substring(1);
      }
      return rest;
    }

    String text;
    switch (kind) {
      case 'FORM':
        text = _formatForm(raw());
        break;
      case 'V':
        text = _evalList(rest).map(toStr).join('');
        break;
      case 'S':
        text = toStr(_eval(rest));
        break;
      default:
        text = raw();
    }
    _write(text);
    if (end == 'L' || end == 'W') _newLine();
    if (end == 'W') await _awaitInput(RunState.waitKey);
  }

  Future<void> _doInput(String rest, bool str) async {
    final r = rest.trim();
    dynamic def;
    if (r.isNotEmpty) def = _eval(r);
    while (true) {
      final s = await _awaitInput(str ? RunState.waitStr : RunState.waitNum);
      if (_disposed) return;
      if (str) {
        vars['RESULTS'] = s;
        return;
      }
      final t = s.trim();
      if (t.isEmpty && def != null) {
        vars['RESULT'] = toInt(def);
        return;
      }
      final n = int.tryParse(t);
      if (n != null) {
        vars['RESULT'] = n;
        return;
      }
    }
  }

  void _doReturn(String rest) {
    final r = rest.trim();
    final vals = r.isEmpty ? <dynamic>[0] : _evalList(r);
    for (var i = 0; i < vals.length; i++) {
      final v = vals[i];
      if (v is String) {
        vars[i == 0 ? 'RESULTS' : 'RESULTS:$i'] = v;
      } else {
        vars[i == 0 ? 'RESULT' : 'RESULT:$i'] = v;
      }
    }
    if (stack.isNotEmpty) stack.removeLast();
  }

  void _doCall(bool soft, String rest) {
    final r = rest.trim();
    final m = _nameRe.firstMatch(r);
    if (m == null) throw EraError('CALL 缺少函式名稱');
    final name = m.group(0)!.toUpperCase();
    var argText = r.substring(m.end).trim();
    if (argText.startsWith('(') && argText.endsWith(')')) {
      argText = argText.substring(1, argText.length - 1);
    } else if (argText.startsWith(',')) {
      argText = argText.substring(1);
    }
    final fn = funcs[name];
    if (fn == null) {
      if (soft) return;
      throw EraError('找不到函式：@$name');
    }
    final args = _evalList(argText);
    final nf = Frame(fn);
    for (var i = 0; i < args.length; i++) {
      final a = args[i];
      final base = a is String ? 'ARGS' : 'ARG';
      nf.locals[i == 0 ? base : '$base:$i'] = a;
    }
    stack.add(nf);
    for (var i = 0; i < fn.params.length && i < args.length; i++) {
      _assignText(fn.params[i], args[i]);
    }
  }

  int _skipIf(Frame f, int ln) {
    final fn = f.fn;
    var t = fn.nextBranch[ln];
    while (t != null) {
      final line = fn.lines[t];
      if (_cmdOf(line) == 'ELSEIF') {
        if (truthy(_eval(line.substring(6)))) return t + 1;
        t = fn.nextBranch[t];
      } else {
        return t + 1;
      }
    }
    return fn.lines.length;
  }

  void _doSelect(Frame f, int ln, String rest) {
    final val = _eval(rest);
    var t = f.fn.nextBranch[ln];
    while (t != null) {
      final line = f.fn.lines[t];
      if (_cmdOf(line) == 'CASE') {
        if (_caseMatch(line.substring(4), val)) {
          f.pc = t + 1;
          return;
        }
        t = f.fn.nextBranch[t];
      } else {
        f.pc = t + 1;
        return;
      }
    }
  }

  bool _caseMatch(String args, dynamic val) {
    for (final part in _splitTop(args)) {
      final isM = _caseIsRe.firstMatch(part);
      if (isM != null) {
        if (truthy(evalBinary(isM.group(1)!, val, _eval(isM.group(2)!)))) {
          return true;
        }
        continue;
      }
      final toM = _caseToRe.firstMatch(part);
      if (toM != null) {
        final lo = _eval(toM.group(1)!);
        final hi = _eval(toM.group(2)!);
        if (truthy(evalBinary('>=', val, lo)) &&
            truthy(evalBinary('<=', val, hi))) {
          return true;
        }
        continue;
      }
      if (truthy(evalBinary('==', val, _eval(part)))) return true;
    }
    return false;
  }

  void _doFor(Frame f, int ln, String rest) {
    final parts = _splitTop(rest.trim());
    if (parts.length < 3) throw EraError('FOR 至少需要 3 個參數');
    final varText = parts[0];
    final start = toInt(_eval(parts[1]));
    final end = toInt(_eval(parts[2]));
    final step = parts.length > 3 ? toInt(_eval(parts[3])) : 1;
    _assignText(varText, start);
    f.forState[ln] = [end, step];
    if (!_forCond(varText, end, step)) f.pc = f.fn.endOf[ln]! + 1;
  }

  bool _forCond(String varText, int end, int step) {
    final v = toInt(_eval(varText));
    return step >= 0 ? v < end : v > end;
  }

  void _doNext(Frame f, int ln) {
    final h = f.fn.startOf[ln]!;
    final st = f.forState[h];
    if (st == null) throw EraError('NEXT 找不到對應的 FOR');
    final varText = _splitTop(f.fn.lines[h].substring(3).trim())[0];
    final v = toInt(_eval(varText)) + st[1];
    _assignText(varText, v);
    if (_forCond(varText, st[0], st[1])) f.pc = h + 1;
  }

  bool _tryAssign(String line) {
    List<Token> toks;
    try {
      toks = _tok(line);
    } on EraError {
      return false;
    }
    final p = ExprParser(toks, this);
    LValue lv;
    try {
      lv = p.parseLValue();
    } on EraError {
      return false;
    }
    final t = p.cur;
    if (t.type != TokType.op) return false;
    final op = t.text;

    if ((op == '+' || op == '-') &&
        p.peek(1).type == TokType.op &&
        p.peek(1).text == op &&
        p.peek(2).type == TokType.end) {
      final old = toInt(getVar(lv.name, lv.idx));
      setVar(lv.name, lv.idx, op == '+' ? old + 1 : old - 1);
      return true;
    }

    const compound = {'+=', '-=', '*=', '/=', '%=', '|=', '&=', '^='};
    if (op != '=' && op != "'=" && !compound.contains(op)) return false;

    dynamic rhs;
    if (op == "'=") {
      var raw = line.substring(t.end);
      if (raw.startsWith(' ')) raw = raw.substring(1);
      rhs = _formatForm(raw);
    } else {
      p.advance();
      rhs = p.parseExpr();
      if (!p.atEnd) throw EraError('指定式右邊有多餘的內容');
    }

    if (op == '=' || op == "'=") {
      setVar(lv.name, lv.idx, rhs);
    } else {
      final old = getVar(lv.name, lv.idx);
      setVar(lv.name, lv.idx, evalBinary(op.substring(0, op.length - 1), old, rhs));
    }
    return true;
  }

  // -------------------------------------------------------------- functions

  @override
  dynamic callFunc(String name, List<dynamic> a) {
    switch (name) {
      case 'RAND':
        if (a.length == 1) {
          final n = toInt(a[0]);
          return n <= 0 ? 0 : _rng.nextInt(n);
        }
        if (a.length == 2) {
          final lo = toInt(a[0]);
          final hi = toInt(a[1]);
          return hi <= lo ? lo : lo + _rng.nextInt(hi - lo);
        }
        break;
      case 'MAX':
        if (a.isNotEmpty) return a.map(toInt).reduce(max);
        break;
      case 'MIN':
        if (a.isNotEmpty) return a.map(toInt).reduce(min);
        break;
      case 'ABS':
        if (a.length == 1) return toInt(a[0]).abs();
        break;
      case 'SIGN':
        if (a.length == 1) return toInt(a[0]).sign;
        break;
      case 'LIMIT':
        if (a.length == 3) {
          return toInt(a[0]).clamp(toInt(a[1]), toInt(a[2])).toInt();
        }
        break;
      case 'POWER':
        if (a.length == 2) return pow(toInt(a[0]), toInt(a[1])).toInt();
        break;
      case 'SQRT':
        if (a.length == 1) return sqrt(toInt(a[0])).floor();
        break;
      case 'TOSTR':
        if (a.isNotEmpty) return toStr(a[0]);
        break;
      case 'TOINT':
        if (a.length == 1) return int.tryParse(toStr(a[0]).trim()) ?? 0;
        break;
      case 'ISNUMERIC':
        if (a.length == 1) return int.tryParse(toStr(a[0]).trim()) != null ? 1 : 0;
        break;
      case 'STRLEN':
      case 'STRLENS':
      case 'STRLENU':
        if (a.length == 1) return toStr(a[0]).length;
        break;
      case 'SUBSTRING':
      case 'SUBSTRINGU':
        if (a.length == 3) {
          final s = toStr(a[0]);
          final st = toInt(a[1]).clamp(0, s.length).toInt();
          final len = toInt(a[2]);
          final en = len < 0 ? s.length : (st + len).clamp(0, s.length).toInt();
          return s.substring(st, en);
        }
        break;
      case 'STRFIND':
      case 'STRFINDU':
        if (a.length >= 2) {
          final s = toStr(a[0]);
          final from = a.length > 2 ? toInt(a[2]).clamp(0, s.length).toInt() : 0;
          return s.indexOf(toStr(a[1]), from);
        }
        break;
      case 'REPLACE':
        if (a.length == 3) {
          return toStr(a[0]).replaceAll(toStr(a[1]), toStr(a[2]));
        }
        break;
      case 'TOUPPER':
        if (a.length == 1) return toStr(a[0]).toUpperCase();
        break;
      case 'TOLOWER':
        if (a.length == 1) return toStr(a[0]).toLowerCase();
        break;
      default:
        throw EraError('不支援的函式：$name');
    }
    throw EraError('函式 $name 的參數數量不正確');
  }
}
