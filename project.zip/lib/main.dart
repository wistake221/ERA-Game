import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'era/expr.dart';
import 'era/interpreter.dart';
import 'era/sample.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const EraApp());
}

class EraApp extends StatelessWidget {
  const EraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ERA Mobile',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const ConsoleScreen(),
    );
  }
}

class ConsoleScreen extends StatefulWidget {
  const ConsoleScreen({super.key});

  @override
  State<ConsoleScreen> createState() => _ConsoleScreenState();
}

class _ConsoleScreenState extends State<ConsoleScreen> {
  late Interpreter _it;
  final ScrollController _scroll = ScrollController();
  final TextEditingController _text = TextEditingController();

  @override
  void initState() {
    super.initState();
    _boot();
  }

  @override
  void dispose() {
    _it.dispose();
    _scroll.dispose();
    _text.dispose();
    super.dispose();
  }

  void _boot() {
    final it = Interpreter();
    try {
      it.loadSource(kSampleScript);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        unawaited(it.start());
      });
    } on EraError catch (e) {
      it.reportError(e.message);
    }
    it.onChange = _onChange;
    _it = it;
  }

  void _restart() {
    final old = _it;
    setState(() {
      _boot();
    });
    old.dispose();
  }

  void _onChange() {
    if (!mounted) return;
    setState(() {});
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  void _submit(String s) {
    _it.submitInput(s);
    _text.clear();
  }

  Widget _bottomBar() {
    switch (_it.state) {
      case RunState.waitNum:
      case RunState.waitStr:
        return Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _text,
                  keyboardType: _it.state == RunState.waitNum
                      ? TextInputType.number
                      : TextInputType.text,
                  decoration: const InputDecoration(
                    isDense: true,
                    hintText: '輸入後按 Enter，或直接點上面的 [數字]',
                  ),
                  onSubmitted: _submit,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send),
                onPressed: () => _submit(_text.text),
              ),
            ],
          ),
        );
      case RunState.waitKey:
        return InkWell(
          onTap: _it.advance,
          child: Container(
            height: 44,
            alignment: Alignment.center,
            child: const Text('▶ 點擊繼續'),
          ),
        );
      case RunState.ended:
        return Padding(
          padding: const EdgeInsets.all(6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('已結束　'),
              FilledButton(onPressed: _restart, child: const Text('重新開始')),
            ],
          ),
        );
      default:
        return const SizedBox(height: 8);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lines = _it.lines;
    final active = _it.waitingInput;
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _it.advance,
                child: ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: lines.length,
                  itemBuilder: (context, i) {
                    final line = lines[i];
                    if (line.rule) {
                      return const Padding(
                        padding: EdgeInsets.symmetric(vertical: 6),
                        child: Divider(height: 1, color: Colors.white54),
                      );
                    }
                    return LineView(
                      line: line,
                      active: active && i >= _it.buttonsFrom,
                      onButton: (n) => _it.submitInput('$n'),
                    );
                  },
                ),
              ),
            ),
            const Divider(height: 1),
            _bottomBar(),
          ],
        ),
      ),
    );
  }
}

class _Btn {
  final int start;
  final int end;
  final int number;
  const _Btn(this.start, this.end, this.number);
}

class LineView extends StatefulWidget {
  final OutLine line;
  final bool active;
  final void Function(int) onButton;

  const LineView({
    super.key,
    required this.line,
    required this.active,
    required this.onButton,
  });

  @override
  State<LineView> createState() => _LineViewState();
}

class _LineViewState extends State<LineView> {
  final List<TapGestureRecognizer> _recs = [];

  void _clear() {
    for (final r in _recs) {
      r.dispose();
    }
    _recs.clear();
  }

  @override
  void dispose() {
    _clear();
    super.dispose();
  }

  List<_Btn> _findButtons(String full) {
    final ms = RegExp(r'\[(\d+)\]').allMatches(full).toList();
    final out = <_Btn>[];
    for (var k = 0; k < ms.length; k++) {
      final start = ms[k].start;
      var end = k + 1 < ms.length ? ms[k + 1].start : full.length;
      while (end > start && (full[end - 1] == ' ' || full[end - 1] == '\u3000')) {
        end--;
      }
      out.add(_Btn(start, end, int.parse(ms[k].group(1)!)));
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    _clear();
    const base = TextStyle(fontSize: 16, height: 1.4, fontFamily: 'monospace');
    final segs = widget.line.segs;
    if (segs.isEmpty) {
      return const Text(' ', style: base);
    }
    final full = widget.line.text;
    final buttons = widget.active ? _findButtons(full) : <_Btn>[];

    final spans = <InlineSpan>[];
    var offset = 0;
    for (final seg in segs) {
      final s = seg.text;
      var i = 0;
      while (i < s.length) {
        final abs = offset + i;
        _Btn? hit;
        for (final b in buttons) {
          if (abs >= b.start && abs < b.end) {
            hit = b;
            break;
          }
        }
        var endAbs = offset + s.length;
        for (final b in buttons) {
          if (b.start > abs && b.start < endAbs) endAbs = b.start;
          if (b.end > abs && b.end < endAbs) endAbs = b.end;
        }
        final chunk = s.substring(i, endAbs - offset);
        if (hit != null) {
          final number = hit.number;
          final rec = TapGestureRecognizer()
            ..onTap = () => widget.onButton(number);
          _recs.add(rec);
          spans.add(TextSpan(
            text: chunk,
            recognizer: rec,
            style: const TextStyle(
              color: Colors.lightBlueAccent,
              decoration: TextDecoration.underline,
            ),
          ));
        } else {
          spans.add(TextSpan(text: chunk, style: TextStyle(color: Color(seg.color))));
        }
        i = endAbs - offset;
      }
      offset += s.length;
    }
    return Text.rich(TextSpan(style: base, children: spans));
  }
}
