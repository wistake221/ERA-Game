import 'package:flutter/material.dart';

void main() => runApp(const EraApp());

class EraApp extends StatelessWidget {
  const EraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ERA Mobile',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const ConsoleScreen(),
    );
  }
}

/// One printed line in the console.
class ConsoleLine {
  final String text;
  final Color color;
  const ConsoleLine(this.text, {this.color = Colors.white});
}

/// One tappable choice (like an ERA numbered button).
class Choice {
  final int id;
  final String label;
  const Choice(this.id, this.label);
}

class ConsoleScreen extends StatefulWidget {
  const ConsoleScreen({super.key});

  @override
  State<ConsoleScreen> createState() => _ConsoleScreenState();
}

class _ConsoleScreenState extends State<ConsoleScreen> {
  final List<ConsoleLine> _lines = [];
  List<Choice> _choices = [];
  final ScrollController _scroll = ScrollController();
  int _day = 1;

  @override
  void initState() {
    super.initState();
    _showTitle();
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _print(String text, {Color color = Colors.white}) {
    _lines.add(ConsoleLine(text, color: color));
  }

  void _showTitle() {
    _lines.clear();
    _print('ERA Mobile  v0.1', color: Colors.amberAccent);
    _print('Android 版 ERA 執行環境（骨架測試）', color: Colors.white70);
    _print('');
    _print('這是測試用的示範畫面，用來確認雲端編譯與介面運作正常。');
    _choices = const [
      Choice(0, '[0] 開始示範'),
      Choice(1, '[1] 關於'),
    ];
  }

  void _showDay() {
    _print('');
    _print('—— 第 $_day 天 ——', color: Colors.lightBlueAccent);
    _print('你要做什麼？');
    _choices = const [
      Choice(10, '[10] 休息'),
      Choice(11, '[11] 外出'),
      Choice(99, '[99] 回到標題'),
    ];
  }

  void _onChoice(Choice c) {
    setState(() {
      _print('> ${c.label}', color: Colors.greenAccent);
      switch (c.id) {
        case 0:
          _day = 1;
          _showDay();
          break;
        case 1:
          _print('之後這裡會顯示遊戲資訊。', color: Colors.white70);
          _choices = const [Choice(98, '[98] 返回')];
          break;
        case 98:
          _showTitle();
          break;
        case 10:
          _print('你好好休息了一下。');
          _day++;
          _showDay();
          break;
        case 11:
          _print('你到外面逛了一圈。');
          _day++;
          _showDay();
          break;
        case 99:
          _showTitle();
          break;
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.all(12),
                itemCount: _lines.length,
                itemBuilder: (context, i) {
                  final line = _lines[i];
                  return Text(
                    line.text.isEmpty ? ' ' : line.text,
                    style: TextStyle(
                      color: line.color,
                      fontSize: 16,
                      height: 1.4,
                      fontFamily: 'monospace',
                    ),
                  );
                },
              ),
            ),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in _choices)
                    OutlinedButton(
                      onPressed: () => _onChoice(c),
                      child: Text(c.label),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
